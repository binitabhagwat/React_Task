import React from 'react';
import { Switch, Route } from 'react-router-dom';
import All from './All';
import WheelSpin from './WheelSpin';
import GoPreference from './GoPreference';
import AndroidSmack from './AndroidSmack';
import AndroidWebService from './AndroidWebService';
import RestrauntProduct from './RestrauntProduct';
import TinyowlLocker from './TinyowlLocker';
import TinyowlApp from './TinyowlApp';

const Main = () => (
  <Switch>
    <Route exact path='/' component={All} />
    <Route exact path='/wheelSpin' component={WheelSpin} />
    <Route exact path='/goPreference' component={GoPreference} />
    <Route exact path='/android-smack' component={AndroidSmack} />
    <Route exact path='/android-web-service' component={AndroidWebService} />
    <Route exact path='/restrauntproduct' component={RestrauntProduct} />
    <Route exact path='/tinyowl-locker' component={TinyowlLocker} />
    <Route exact path='/tinyowl.app' component={TinyowlApp} />
  </Switch>
)

export default Main
