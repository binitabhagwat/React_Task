import React from 'react'
import { Link } from 'react-router-dom';
import '../App.css';

const AndroidWebService = () => (
    <div className="new-content-container">
    <li className="li-style-none"><Link to='/'>Home</Link></li>
    <h1>Android-Web-Service</h1>
    </div>
)

export default AndroidWebService