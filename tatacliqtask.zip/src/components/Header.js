import React from 'react'
import { Link } from 'react-router-dom';
import '../App.css';

class Header extends React.Component {
  constructor(props) {
    super(props);
  }
  state = {
    items: [],
    activeIndex: 0,
  }
  componentDidMount() {
    fetch("./data.json")
      .then(res => res.json()
      )
      .then(
      (result) => {
        console.log(result);
        this.setState({
          isLoaded: true,
          items: result.items
        });
      },
      (error) => {
        this.setState({
          isLoaded: true,
          error
        });
      }
      )
  }
  changeCurrentTab = (e,index) => {
    e.preventDefault();
    console.log('efwfsdfsdfsd')
    this.setState({
      activeIndex: index,
    })
    return false;
  }
  getMyTabContent = (tab, items) => {
    const newTabContent = [];
    items.forEach((item, index) => {
      if (tab.id === item.type||tab.id==='All') {
        newTabContent.push(<li className="li-style-none" key={index}><img src={item.imageUrl} />
          <Link to={item.name}>{item.name}</Link>
        </li>)
      }
    })
    console.log('*********',newTabContent)
    return newTabContent;
  }
  render() {
    const { items } = this.state;
    const myTabs = [
    {
      name: "All",
      id: "All"
    },
    {
      name: "Public",
      id: "public"
    },
    {
      name: "Private",
      id: "private"
    },
    {
      name: "Sources",
      id: "sources"
    },
    {
      name: "Forks",
      id: "forks"
    }]
    const self = this;
    console.log('active index',this.state.activeIndex)
    return (
      <div>
        <div className="tabs">
          <input className="form-control-input" id="search" type="text" placeholder="Find a repository..." />
          <div id="divID">
            <ul id="minitabs" className="nav nav-tabs">
              {myTabs.map((tab, index) => {
                return (
                  <li key={index} className={index === this.state.activeIndex ? "active" : ""}>
                    <a href="javascript:void(0)"  onClick={(e)=>this.changeCurrentTab(e,index)}>{tab.name}</a>
                  </li>
                )
              })}
            </ul>
            <div className="tab-content">
              {myTabs.map((tab, index) => {
                return (<div key={index} id={tab.id} className={index === this.state.activeIndex ?  "tab-pane active in": "tab-pane"}>
                  {this.getMyTabContent(tab, items)}
                </div>)
              })}

            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Header