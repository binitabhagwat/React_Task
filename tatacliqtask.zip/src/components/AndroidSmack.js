import React from 'react'
import { Link } from 'react-router-dom';
import '../App.css';

const AndroidSmack = () => (
    <div className="new-content-container">
    <li className="li-style-none"><Link to='/'>Home</Link></li>
    <h1>android-smack</h1>
    </div>
)

export default AndroidSmack