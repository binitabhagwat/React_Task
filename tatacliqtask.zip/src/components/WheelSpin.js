import React from 'react'
import { Link } from 'react-router-dom';
import '../App.css';

const WheelSpin = () => (
    <div className="new-content-container">
    <li className="li-style-none"><Link to='/'>Home</Link></li>
    <h1>WheelSpin</h1>
    </div>
)

export default WheelSpin