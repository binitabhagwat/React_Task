import React from 'react'
import { Link } from 'react-router-dom';
import '../App.css';

const TinyowlApp = () => (
    <div className="new-content-container">
    <li className="li-style-none"><Link to='/'>Home</Link></li>
    <h1>TinyowlApp</h1>
    </div>
)

export default TinyowlApp