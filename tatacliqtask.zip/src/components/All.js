import React, { Component } from 'react';
import Main from './Main';
import Header from './Header';
import '../App.css';


class Page extends Component {
   
    render() {
      return ( <p></p>)
    }

}
export default Page;