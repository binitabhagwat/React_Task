import React, { Component } from 'react';
import './App.css';
import Header from './components/Header';
import Main from './components/Main';
class App extends Component {
  
  // handleRedirect(e, name) {
  //   e.preventDefault();
  //   console.log(name);

  // }
  render() {

    // if (error) {
    //   return <div>Error: {error.message}</div>;
    // } else if (!isLoaded) {
    //   return <div>Loading...</div>;
    // } else {
      return (
        <div className="App">
          <div className="main-border">
            <div className="header-content">
              <div className="heading-container">
                <h1>Your Repositories 7</h1>
              </div>
              <div className="button-container">
                <input type="button" value="New repository" className="button-new" />
              </div>
            </div>
            <div className="main-content">
            <Header />
            <Main />
            </div>
          </div>
        </div>
      );
  //   }
  // }
}
}

export default App;
